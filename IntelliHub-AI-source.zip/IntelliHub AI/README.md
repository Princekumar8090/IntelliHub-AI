# IntelliHub AI — Local Ollama version

This version replaces the Gemini API with a locally running Ollama model. It retains the Streamlit pages, SQLite history, local document retrieval, application tracker, study planner, charts and document uploads. No cloud API key or API credits are required.

## Windows setup

1. Install Ollama from https://ollama.com/ and start it.
2. Open PowerShell and download the model:

   ```powershell
   ollama pull llama3.2:3b
   ```

3. Check the model is available:

   ```powershell
   ollama list
   ```

4. Copy `app.py`, `requirements.txt`, and `.env.example` into your project folder. Keep your existing `data/` and `documents/` folders so your local records and uploaded files remain available. Rename `.env.example` to `.env` if you want to configure the model/base URL.
5. Activate your virtual environment and install requirements:

   ```powershell
   pip install -r requirements.txt
   ```

6. Run the app:

   ```powershell
   streamlit run app.py
   ```

Open http://localhost:8501 if the browser does not open automatically.

## Notes

- Default model: `llama3.2:3b`.
- Default Ollama URL: `http://localhost:11434`.
- No Gemini/OpenAI API key is used.
- Live web search is not available in this local-only version. Verify current job listings, deadlines, courses and company information on official websites.
- Generation speed and quality depend on your computer's RAM, CPU/GPU and the selected local model.
